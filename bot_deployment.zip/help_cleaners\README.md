# Help Cleaners Bot (aiogram 3)

Minimal MVP per spec: isolated per-group data, registration, shifts, today, basic photo logging, and reminder job scaffolding.

## Quick start

1. Create a virtualenv and install deps:

```powershell
cd help_cleaners
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Create `.env` in the project root with:

```
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
ENV=development
DATABASE_URL=sqlite+aiosqlite:///./data/dev.db
```

3. Run the bot:

```powershell
python main.py
```

## Commands
- /register [name] — register in this group (display name ≤10 chars)
- /shift [YYYY-MM-DD] [day|night] — add/update shift
- /today — show who is on shifts today

Photos sent in the group by registered members are logged with basic duplicate suppression. 