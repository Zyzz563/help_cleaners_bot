# PowerShell скрипт для развертывания Help Cleaners Bot

Write-Host "🚀 Развертывание Help Cleaners Bot..." -ForegroundColor Green

# Проверка наличия .env файла
if (-not (Test-Path ".env")) {
    Write-Host "❌ Файл .env не найден! Создайте его с BOT_TOKEN" -ForegroundColor Red
    exit 1
}

# Остановка и удаление старых контейнеров
Write-Host "🔄 Остановка старых контейнеров..." -ForegroundColor Yellow
docker-compose down

# Сборка и запуск
Write-Host "🔨 Сборка и запуск бота..." -ForegroundColor Yellow
docker-compose up -d --build

# Проверка статуса
Write-Host "✅ Проверка статуса..." -ForegroundColor Green
docker-compose ps

# Показ логов
Write-Host "📋 Логи бота (Ctrl+C для выхода):" -ForegroundColor Cyan
docker-compose logs -f bot 