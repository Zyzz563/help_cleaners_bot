# 🚀 Развертывание Help Cleaners Bot на сервере

## 📋 Быстрый старт (5 минут)

### 1. Заказ VPS сервера
- **Timeweb** - от 200₽/мес (рекомендую)
- **Reg.ru** - от 250₽/мес
- **Beget** - от 300₽/мес

**Минимальные требования:**
- Ubuntu 22.04 LTS
- 1 CPU, 1 GB RAM, 10 GB SSD
- Доступ по SSH

### 2. Подключение к серверу
```bash
ssh root@YOUR_SERVER_IP
```

### 3. Автоматическая настройка
```bash
# Скачивание проекта
wget https://github.com/YOUR_USERNAME/help_cleaners/archive/main.zip
unzip main.zip
cd help_cleaners-main

# Настройка сервера
chmod +x setup_server.sh
./setup_server.sh

# Перезагрузка или переподключение
exit
ssh root@YOUR_SERVER_IP
```

### 4. Настройка бота
```bash
cd ~/help_cleaners
cp env.example .env
nano .env
```

**В .env файле укажите:**
```env
BOT_TOKEN=YOUR_ACTUAL_BOT_TOKEN
ENV=production
DATABASE_URL=sqlite+aiosqlite:///./data/prod.db
```

### 5. Запуск бота
```bash
chmod +x deploy.sh
./deploy.sh
```

## 🔧 Управление ботом

### Просмотр логов
```bash
docker-compose logs -f bot
```

### Перезапуск
```bash
docker-compose restart bot
```

### Обновление
```bash
git pull
docker-compose up -d --build
```

### Остановка
```bash
docker-compose down
```

## 📱 Получение Bot Token

1. Напишите @BotFather в Telegram
2. Команда: `/newbot`
3. Укажите имя и username бота
4. Скопируйте полученный токен в .env файл

## 🛡️ Безопасность

- Бот работает только в разрешенных группах
- ID групп указаны в `app/config.py`
- Только владелец может добавлять новые группы

## 📊 Мониторинг

```bash
# Статус контейнеров
docker-compose ps

# Использование ресурсов
htop

# Логи системы
journalctl -u docker
```

## 🆘 Решение проблем

### Бот не отвечает
```bash
docker-compose logs bot
```

### Ошибка с правами
```bash
sudo chown -R $USER:$USER ~/help_cleaners
```

### Проблемы с Docker
```bash
sudo systemctl restart docker
```

## 💰 Стоимость

- **VPS**: 200-300₽/мес
- **Домен** (опционально): 100₽/год
- **SSL сертификат**: бесплатно (Let's Encrypt)

**Итого: ~250₽/мес за стабильную работу бота!** 