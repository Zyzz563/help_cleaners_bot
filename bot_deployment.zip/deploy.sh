#!/bin/bash

# Deployment script for help_cleaners bot
# Usage: ./deploy.sh

echo "🚀 Starting deployment of help_cleaners bot..."

# Update system packages
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python 3.11 and pip
echo "🐍 Installing Python 3.11..."
sudo apt install -y python3.11 python3.11-venv python3.11-pip

# Install system dependencies for image processing
echo "🖼️ Installing image processing dependencies..."
sudo apt install -y libjpeg-dev zlib1g-dev libfreetype6-dev liblcms2-dev libopenjp2-7-dev libtiff5-dev

# Create bot directory
echo "📁 Creating bot directory..."
mkdir -p ~/help_cleaners_bot
cd ~/help_cleaners_bot

# Create virtual environment
echo "🔧 Creating Python virtual environment..."
python3.11 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📚 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create systemd service for auto-start
echo "⚙️ Creating systemd service..."
sudo tee /etc/systemd/system/help-cleaners-bot.service > /dev/null <<EOF
[Unit]
Description=Help Cleaners Telegram Bot
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$HOME/help_cleaners_bot
Environment=PATH=$HOME/help_cleaners_bot/venv/bin
ExecStart=$HOME/help_cleaners_bot/venv/bin/python start_bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
echo "🚀 Enabling and starting bot service..."
sudo systemctl daemon-reload
sudo systemctl enable help-cleaners-bot
sudo systemctl start help-cleaners-bot

# Check status
echo "📊 Checking bot status..."
sudo systemctl status help-cleaners-bot

echo "✅ Deployment completed!"
echo "📝 Bot logs: sudo journalctl -u help-cleaners-bot -f"
echo "🛑 Stop bot: sudo systemctl stop help-cleaners-bot"
echo "▶️  Start bot: sudo systemctl start help-cleaners-bot"
echo "🔄 Restart bot: sudo systemctl restart help-cleaners-bot" 