#!/bin/bash

echo "🚀 Развертывание Help Cleaners Bot..."

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo "❌ Файл .env не найден! Создайте его с BOT_TOKEN"
    exit 1
fi

# Остановка и удаление старых контейнеров
echo "🔄 Остановка старых контейнеров..."
docker-compose down

# Сборка и запуск
echo "🔨 Сборка и запуск бота..."
docker-compose up -d --build

# Проверка статуса
echo "✅ Проверка статуса..."
docker-compose ps

# Показ логов
echo "📋 Логи бота (Ctrl+C для выхода):"
docker-compose logs -f bot 