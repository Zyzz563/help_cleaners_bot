from __future__ import annotations

import asyncio
from datetime import datetime, date, time, timedelta
from typing import Optional

from aiogram import Router, F
from aiogram.filters import Command, StateFilter
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import select, func, insert, delete, update
from sqlalchemy.ext.asyncio import AsyncSession
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.filters.chat_member_updated import ChatMemberUpdatedFilter, KICKED, MEMBER
from aiogram.types import ChatMemberUpdated
from aiogram.types import InputMediaPhoto
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.config import MAX_NAME_LEN, default_group_config, OWNER_ID, ALLOWED_CHATS
from app.db.models import Group, Member, Shift, Photo, PhotoDuplicate, ProcessedCallback, Timesheet, AllowedChat
from app.db.session import create_session_maker
from app.keyboards import day_night_kb, register_name_kb, gender_kb, start_kb, remove_menu_kb, members_choice_kb
from app.utils.text import is_valid_display_name
from app.utils.time import parse_hhmm, local_today, local_now

router = Router()


async def check_user_allowed(message: Message) -> bool:
	"""
	🔒 Проверяет разрешен ли пользователь для работы с ботом.
	Только владелец (OWNER_ID) может использовать команды.
	"""
	if not message.from_user:
		return False
	
	# Только владелец может использовать команды
	return message.from_user.id == OWNER_ID


async def check_chat_allowed(message: Message, session: AsyncSession) -> bool:
	"""
	🔒 Проверяет разрешен ли чат для работы бота.
	Возвращает True если чат разрешен, False если нет.
	"""
	chat_id = message.chat.id
	
	# Сначала проверяем в конфигурации (для быстрого доступа)
	if chat_id in ALLOWED_CHATS:
		return True
	
	# Затем проверяем в БД
	allowed_chat = await session.execute(
		select(AllowedChat).where(
			AllowedChat.chat_id == chat_id,
			AllowedChat.is_active == True
		)
	)
	
	if allowed_chat.scalar_one_or_none():
		return True
	
	# Если чат не разрешен - бот уходит
	await message.reply("❌ Этот бот не разрешён для использования в данной группе.")
	try:
		await message.chat.leave()
	except Exception:
		pass  # Игнорируем ошибки при выходе
	
	return False


async def check_owner_permission(message: Message) -> bool:
	"""
	🔒 Проверяет является ли пользователь владельцем бота.
	"""
	return message.from_user and message.from_user.id == OWNER_ID


async def auto_delete_message(message: Message, delay_seconds: int = 60):
	"""Автоматически удаляет сообщение через указанное время"""
	await asyncio.sleep(delay_seconds)
	try:
		await message.delete()
	except Exception:
		pass  # Игнорируем ошибки удаления


async def cleanup_registration_messages(messages_to_delete: list, delay_seconds: int = 60):
	"""Удаляет все сообщения процесса регистрации через указанное время"""
	await asyncio.sleep(delay_seconds)
	for msg in messages_to_delete:
		try:
			await msg.delete()
		except Exception:
			pass  # Игнорируем ошибки удаления


async def ensure_group(session: AsyncSession, chat_id: int, title: Optional[str]) -> Group:
	existing = await session.get(Group, chat_id)
	if existing:
		return existing
	cfg = default_group_config()
	group = Group(
		chat_id=chat_id,
		title=title,
		tz=cfg["tz"],
		day_start=parse_hhmm(cfg["day_start"]),
		day_end=parse_hhmm(cfg["day_end"]),
		night_start=parse_hhmm(cfg["night_start"]),
		night_end=parse_hhmm(cfg["night_end"]),
		reminder_interval_min=cfg["reminder_interval_min"],
		lunch_start=parse_hhmm(cfg["lunch_start"]),
		lunch_end=parse_hhmm(cfg["lunch_end"]),
		updated_at=datetime.utcnow(),
	)
	session.add(group)
	await session.commit()
	return group


async def is_admin(chat_id: int, user_id: int, bot) -> bool:
	try:
		cm = await bot.get_chat_member(chat_id, user_id)
		return cm.status in {"administrator", "creator", "owner"}
	except Exception:
		return False


async def schedule_reminders_for_shift(chat_id: int, shift_date: date, shift_type: str, session: AsyncSession) -> None:
	# TODO: integrate real scheduler. Placeholder for MVP.
	return None


class RegStates(StatesGroup):
	waiting_name = State()
	waiting_gender = State()
	
	# Таймауты для состояний (в секундах)
	waiting_name_timeout = 300  # 5 минут на ввод имени
	waiting_gender_timeout = 300  # 5 минут на выбор пола


@router.message(Command("register"))
async def cmd_register(message: Message, session: AsyncSession, state: FSMContext):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return

	chat_id = message.chat.id
	group = await ensure_group(session, chat_id, message.chat.title)

	# Check if user is trying to register someone else (admin only)
	args = message.text.split(maxsplit=1)
	target_user_id = message.from_user.id
	
	if len(args) >= 2:
		# Admin pattern: /register 123456789 — допускаем независимо от текущего состояния
		if not await is_admin(chat_id, message.from_user.id, message.bot):
			reply_msg = await message.reply("❌ Регистрировать других может только админ.")
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(reply_msg)
			await state.update_data(messages_to_delete=messages_to_delete)
			return
		try:
			target_user_id = int(args[1])
			# Check if user exists in chat
			chat_member = await message.bot.get_chat_member(chat_id, target_user_id)
			if chat_member.status in ['left', 'kicked']:
				reply_msg = await message.reply("❌ Указанный пользователь не находится в группе.")
				data = await state.get_data()
				messages_to_delete = data.get("messages_to_delete", [])
				messages_to_delete.append(reply_msg)
				await state.update_data(messages_to_delete=messages_to_delete)
				return
		except (ValueError, Exception):
			reply_msg = await message.reply("❌ Неверный формат ID. Используйте: /register 123456789")
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(reply_msg)
			await state.update_data(messages_to_delete=messages_to_delete)
			return
		# Check if target user is already registered
		existing_target = await session.get(Member, {"chat_id": chat_id, "user_id": target_user_id})
		if existing_target:
			reply_msg = await message.reply(f"Пользователь {existing_target.display_name} уже зарегистрирован в этой группе.")
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(reply_msg)
			await state.update_data(messages_to_delete=messages_to_delete)
			return
		# Start registration for target user
		await state.update_data(target_user_id=target_user_id)
		reply_msg = await message.reply(f"Регистрирую пользователя ID:{target_user_id}. Введите его имя (1..{MAX_NAME_LEN} символов):")
		await state.set_state(RegStates.waiting_name)
		await state.update_data(messages_to_delete=[message, reply_msg])
		return

	# Anti-duplication for self-registration only
	st = await state.get_state()
	if st == RegStates.waiting_gender.state:
		reply_msg = await message.reply("Вы уже в процессе регистрации: выберите пол на предыдущем сообщении или отправьте /reset, чтобы начать заново.")
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		messages_to_delete.append(reply_msg)
		await state.update_data(messages_to_delete=messages_to_delete)
		return
	if st == RegStates.waiting_name.state:
		reply_msg = await message.reply(f"Регистрация уже начата: введите имя (1..{MAX_NAME_LEN} символов) или отправьте /reset, чтобы начать заново.")
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		messages_to_delete.append(reply_msg)
		await state.update_data(messages_to_delete=messages_to_delete)
		return

	# Self-registration flow
	if message.from_user.username:
		kb = register_name_kb(message.from_user.username if message.from_user else None)
		reply = await message.reply(f"Отправьте имя/ник (1..{MAX_NAME_LEN} символов) или нажмите кнопку", reply_markup=kb)
		await state.set_state(RegStates.waiting_name)
		await state.update_data(messages_to_delete=[message, reply])
		return

	# Без username предлагаем вручную ввести имя, не завершаем регистрацию автоматически
	reply = await message.reply(f"Отправьте имя/ник (1..{MAX_NAME_LEN} символов)")
	await state.set_state(RegStates.waiting_name)
	await state.update_data(messages_to_delete=[message, reply])


@router.message(StateFilter(RegStates.waiting_name), F.text)
async def on_manual_name(message: Message, session: AsyncSession, state: FSMContext):
	# Сразу отвечаем - "обрабатываю"
	processing_msg = await message.reply("⏳ Обрабатываю...")
	
	try:
		text = (message.text or "").strip()
		# If user typed a command instead of a name, cancel registration step and dispatch the command
		if text.startswith('/'):
			await state.clear()
			await processing_msg.delete()
			cmd = text.split()[0].split('@')[0]
			if cmd == '/shift':
				await cmd_shift(message, session)
				return
			if cmd == '/today':
				await cmd_today(message, session)
				return
			if cmd == '/cleaners':
				await cmd_cleaners(message, session)
				return
			if cmd == '/register':
				await cmd_register(message, session, state)
				return
			if cmd == '/analyze_duplicates':
				await cmd_analyze_duplicates(message, session)
				return
			if cmd == '/tabel':
				await cmd_tabel(message, session)
				return
		
		# Get target_user_id from state (for admin registration) or use current user
		data = await state.get_data()
		target_user_id = data.get("target_user_id", message.from_user.id)
		
		# Validate the name
		if not is_valid_display_name(text):
			reply_msg = await processing_msg.edit_text(f"❌ Имя должно быть 1..{MAX_NAME_LEN} символов, без пробелов/эмодзи. Введите снова.")
			# Добавляем сообщение к списку для удаления
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(processing_msg)
			await state.update_data(messages_to_delete=messages_to_delete)
			return
		
		# Remove "processing" message and continue
		await processing_msg.delete()
		await _complete_registration(message, session, state, message.chat.id, text, target_user_id=target_user_id)
		
	except Exception as e:
		# В случае ошибки - очищаем состояние и сообщаем
		await processing_msg.edit_text(f"❌ Ошибка: {str(e)}. Попробуйте /register снова.")
		
		# Добавляем сообщение к списку для удаления
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		messages_to_delete.append(processing_msg)
		await state.update_data(messages_to_delete=messages_to_delete)
		
		await state.clear()


async def _complete_registration(message: Message, session: AsyncSession, state: FSMContext, chat_id: int, candidate: str, *, target_user_id: int) -> None:
	try:
		# Проверяем существующую регистрацию
		existing_self = await session.get(Member, {"chat_id": chat_id, "user_id": target_user_id})
		if existing_self:
			if target_user_id == message.from_user.id:
				reply_msg = await message.reply(f"✅ Вы уже зарегистрированы как {existing_self.display_name}.")
			else:
				reply_msg = await message.reply(f"✅ Пользователь {existing_self.display_name} уже зарегистрирован в этой группе.")
			
			# Добавляем сообщение к списку для удаления
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(reply_msg)
			await state.update_data(messages_to_delete=messages_to_delete)
			
			await state.clear()
			return
		
		# Проверяем уникальность имени в группе (исключая того же пользователя)
		q = select(Member).where(
			Member.chat_id == chat_id,
			func.lower(Member.display_name) == func.lower(candidate),
		)
		exists = (await session.execute(q)).scalar_one_or_none()
		if exists and exists.user_id != target_user_id:
			reply = await message.reply("❌ Такое имя уже занято в этой группе. Введите другое или используйте формат Имя|user_id")
			
			# Добавляем сообщение к списку для удаления
			data = await state.get_data()
			messages_to_delete = data.get("messages_to_delete", [])
			messages_to_delete.append(reply)
			await state.update_data(messages_to_delete=messages_to_delete)
			
			await state.set_state(RegStates.waiting_name)
			return

		await state.update_data(display_name=candidate, target_user_id=target_user_id)
		
		# Разные сообщения для саморегистрации и регистрации других
		if target_user_id == message.from_user.id:
			reply = await message.reply("✅ Имя принято! Теперь выберите пол:", reply_markup=gender_kb())
		else:
			# Получаем информацию о регистрируемом пользователе
			try:
				chat_member = await message.bot.get_chat_member(chat_id, target_user_id)
				user_info = f"@{chat_member.user.username}" if chat_member.user.username else f"ID:{target_user_id}"
				reply = await message.reply(f"✅ Регистрирую {user_info} как '{candidate}'. Теперь выберите пол:", reply_markup=gender_kb())
			except Exception:
				reply = await message.reply(f"✅ Регистрирую пользователя ID:{target_user_id} как '{candidate}'. Теперь выберите пол:", reply_markup=gender_kb())
		
		await state.set_state(RegStates.waiting_gender)
		
		# Добавляем сообщение к списку для удаления
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		messages_to_delete.append(message)  # Сообщение пользователя с именем
		messages_to_delete.append(reply)    # Сообщение бота с кнопками
		await state.update_data(messages_to_delete=messages_to_delete)
		
	except Exception as e:
		reply_msg = await message.reply(f"❌ Ошибка при проверке имени: {str(e)}. Попробуйте /register снова.")
		
		# Добавляем сообщение к списку для удаления
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		messages_to_delete.append(reply_msg)
		await state.update_data(messages_to_delete=messages_to_delete)
		
		await state.clear()


@router.callback_query(StateFilter(RegStates.waiting_gender), F.data.startswith("gender:"))
async def on_gender(callback: CallbackQuery, session: AsyncSession, state: FSMContext):
	try:
		# Сразу отвечаем на callback
		await callback.answer("⏳ Сохраняю...")
		
		gender = callback.data.split(":", 1)[1]
		if gender not in {"m", "f"}:
			await callback.answer("❌ Неверный пол", show_alert=True)
			return
		
		data = await state.get_data()
		display_name = data.get("display_name")
		target_user_id = data.get("target_user_id")
		
		if not display_name or not target_user_id:
			await callback.answer("❌ Ошибка состояния. Повторите /register", show_alert=True)
			await state.clear()
			return
		
		# Upsert: if member exists, update name/gender; else create
		member = await session.get(Member, {"chat_id": callback.message.chat.id, "user_id": int(target_user_id)})
		if member:
			member.display_name = display_name
			member.gender = gender
		else:
			member = Member(
				chat_id=callback.message.chat.id,
				user_id=int(target_user_id),
				display_name=display_name,
				role="cleaner",
				registered_at=datetime.utcnow(),
				gender=gender,
			)
			session.add(member)
		
		await session.commit()
		
		# Успешная регистрация
		gender_text = "мужской" if gender == "m" else "женский"
		
		# Разные сообщения для саморегистрации и регистрации других
		if int(target_user_id) == callback.from_user.id:
			await callback.message.edit_text(f"✅ Регистрация завершена!\n\n👤 Имя: {display_name}\n🚹 Пол: {gender_text}\n\nТеперь вы можете использовать команды /shift, /today, /myshifts")
		else:
			# Получаем информацию о зарегистрированном пользователе
			try:
				chat_member = await callback.bot.get_chat_member(callback.message.chat.id, int(target_user_id))
				user_info = f"@{chat_member.user.username}" if chat_member.user.username else f"ID:{target_user_id}"
				await callback.message.edit_text(f"✅ Регистрация завершена!\n\n👤 Пользователь: {user_info}\n📝 Имя: {display_name}\n🚹 Пол: {gender_text}\n\nПользователь может использовать команды /shift, /today, /myshifts")
			except Exception:
				await callback.message.edit_text(f"✅ Регистрация завершена!\n\n👤 Пользователь: ID:{target_user_id}\n📝 Имя: {display_name}\n🚹 Пол: {gender_text}\n\nПользователь может использовать команды /shift, /today, /myshifts")
		
		# Удаляем все предыдущие сообщения процесса регистрации
		data = await state.get_data()
		messages_to_delete = data.get("messages_to_delete", [])
		if messages_to_delete:
			asyncio.create_task(cleanup_registration_messages(messages_to_delete, 2))
		
		await state.clear()
		
	except Exception as e:
		await callback.answer(f"❌ Ошибка: {str(e)}", show_alert=True)
		await state.clear()


@router.callback_query(F.data == "regname:use_username")
async def cb_use_username(callback: CallbackQuery, session: AsyncSession, state: FSMContext):
	username = callback.from_user.username
	if not username:
		await callback.answer("У вас нет username. Введите вручную.", show_alert=True)
		return
	chat_id = callback.message.chat.id
	await ensure_group(session, chat_id, callback.message.chat.title)
	# If already registered, just inform
	existing = await session.get(Member, {"chat_id": chat_id, "user_id": callback.from_user.id})
	if existing:
		await callback.message.answer(f"Вы уже зарегистрированы как {existing.display_name}.")
		await callback.answer()
		return
	# If name taken by other user, ask manual
	q = select(Member).where(Member.chat_id == chat_id, func.lower(Member.display_name) == func.lower(username))
	taken = (await session.execute(q)).scalar_one_or_none()
	if taken and taken.user_id != callback.from_user.id:
		await callback.message.answer("Это имя занято в группе. Нажмите 'Ввести вручную' и укажите Имя или Имя|user_id")
		await callback.answer()
		await state.set_state(RegStates.waiting_name)
		return
	# proceed to gender
	await state.update_data(display_name=username, target_user_id=callback.from_user.id)
	await callback.message.answer("Выберите пол:", reply_markup=gender_kb())
	await state.set_state(RegStates.waiting_gender)
	await callback.answer()


@router.callback_query(F.data == "regname:manual")
async def cb_manual(callback: CallbackQuery, state: FSMContext):
	st = await state.get_state()
	if st == RegStates.waiting_gender.state:
		await callback.answer()
		return
	reply_msg = await callback.message.answer("Введите имя (1..10 символов)")
	await state.set_state(RegStates.waiting_name)
	await callback.answer()
	
	# Добавляем сообщение к списку для удаления
	data = await state.get_data()
	messages_to_delete = data.get("messages_to_delete", [])
	messages_to_delete.append(reply_msg)
	await state.update_data(messages_to_delete=messages_to_delete)


@router.message(Command("shift"))
async def cmd_shift(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return

	chat_id = message.chat.id
	user_id = message.from_user.id if message.from_user else 0
	group = await ensure_group(session, chat_id, message.chat.title)
	today = local_today(group.tz)

	args = (message.text or "").split()
	# Usage: /shift [YYYY-MM-DD] [day|night|day_night]
	shift_date = today
	shift_type: Optional[str] = None
	if len(args) >= 2:
		try:
			shift_date = date.fromisoformat(args[1])
		except Exception:
			shift_date = today
	if len(args) >= 3 and args[2] in {"day", "night", "day_night"}:
		shift_type = args[2]

	if shift_type is None:
		# Проверяем есть ли уже смена сегодня для умной клавиатуры
		existing_shift = await session.execute(
			select(Shift).where(Shift.chat_id == chat_id, Shift.user_id == user_id, Shift.date == shift_date)
		)
		current_shift = existing_shift.scalar_one_or_none()
		
		if current_shift:
			if current_shift.type == "day":
				# Уже есть дневная - предлагаем ночную или комбо
				await message.reply(f"У вас уже есть дневная смена на {shift_date.strftime('%d.%m')}.\nВыберите продолжение:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
					[InlineKeyboardButton(text="Только ночная", callback_data="shift:night")],
					[InlineKeyboardButton(text="День+Ночь", callback_data="shift:day_night")]
				]))
			elif current_shift.type == "night":
				# Уже есть ночная - предлагаем дневную или комбо  
				# Ночная смена записана на следующий день, показываем правильную дату
				from datetime import timedelta
				night_shift_date = shift_date + timedelta(days=1)
				await message.reply(f"У вас уже есть ночная смена на {night_shift_date.strftime('%d.%m')}.\nВыберите продолжение:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
					[InlineKeyboardButton(text="Только дневная", callback_data="shift:day")],
					[InlineKeyboardButton(text="День+Ночь", callback_data="shift:day_night")]
				]))
			else:
				# Уже комбо - просто стандартная клавиатура
				await message.reply("Выберите смену:", reply_markup=day_night_kb())
		else:
			# Нет смены - стандартная клавиатура
		await message.reply("Выберите смену:", reply_markup=day_night_kb())
		return

	if shift_type == "day_night":
		# Создаем дневную смену на сегодня
		await _upsert_shift(session, chat_id, user_id, shift_date, "day")
		await schedule_reminders_for_shift(chat_id, shift_date, "day", session)
		
		# Создаем ночную смену на следующий день
		from datetime import timedelta
		next_day = shift_date + timedelta(days=1)
		await _upsert_shift(session, chat_id, user_id, next_day, "night")
		await schedule_reminders_for_shift(chat_id, next_day, "night", session)
		
		reply = await message.reply(f"Комбо смена записана:\n🌅 Дневная: {shift_date.isoformat()}\n🌙 Ночная: {next_day.isoformat()}")
	elif shift_type == "night":
		# 🌙 Ночная смена: с 21:00 до 09:00 - записываем на СЛЕДУЮЩИЙ день!
		from datetime import timedelta
		next_day = shift_date + timedelta(days=1)
		await _upsert_shift(session, chat_id, user_id, next_day, "night")
		await schedule_reminders_for_shift(chat_id, next_day, "night", session)
		
		reply = await message.reply(f"Смена записана: ночная {next_day.isoformat()}")
	else:
		# 🌅 Дневная смена: с 09:00 до 21:00 - записываем на текущий день
		await _upsert_shift(session, chat_id, user_id, shift_date, shift_type)
	await schedule_reminders_for_shift(chat_id, shift_date, shift_type, session)
		
		shift_name = {"day": "дневная"}[shift_type]
		reply = await message.reply(f"Смена записана: {shift_name} {shift_date.isoformat()}")
	
	asyncio.create_task(_autodelete(message, reply))


@router.callback_query(F.data.startswith("shift:"))
async def cb_shift(callback: CallbackQuery, session: AsyncSession):
	shift_type = callback.data.split(":", 1)[1]
	chat_id = callback.message.chat.id
	user_id = callback.from_user.id

	# Idempotency: skip if this callback id was already processed
	cb_id = f"{callback.id}"
	existing = await session.get(ProcessedCallback, cb_id)
	if existing:
		await callback.answer()
		return

	group = await ensure_group(session, chat_id, callback.message.chat.title)
	shift_date = local_today(group.tz)

	if shift_type == "day_night":
		# Создаем дневную смену на сегодня
		await _upsert_shift(session, chat_id, user_id, shift_date, "day")
		await schedule_reminders_for_shift(chat_id, shift_date, "day", session)
		
		# Создаем ночную смену на следующий день
		from datetime import timedelta
		next_day = shift_date + timedelta(days=1)
		await _upsert_shift(session, chat_id, user_id, next_day, "night")
		await schedule_reminders_for_shift(chat_id, next_day, "night", session)
		
		await callback.message.answer(f"Комбо смена записана:\n🌅 Дневная: {shift_date.isoformat()}\n🌙 Ночная: {next_day.isoformat()}")
	elif shift_type == "night":
		# 🌙 Ночная смена: с 21:00 до 09:00 - записываем на СЛЕДУЮЩИЙ день!
		from datetime import timedelta
		next_day = shift_date + timedelta(days=1)
		await _upsert_shift(session, chat_id, user_id, next_day, "night")
		await schedule_reminders_for_shift(chat_id, next_day, "night", session)
		
		await callback.message.answer(f"Смена записана: ночная {next_day.isoformat()}")
	else:
		# 🌅 Дневная смена: с 09:00 до 21:00 - записываем на текущий день
		await _upsert_shift(session, chat_id, user_id, shift_date, shift_type)
	await schedule_reminders_for_shift(chat_id, shift_date, shift_type, session)
		
		shift_name = {"day": "дневная"}[shift_type]
		await callback.message.answer(f"Смена записана: {shift_name} {shift_date.isoformat()}")
	
	# mark processed
	session.add(ProcessedCallback(id=cb_id, created_at=datetime.utcnow()))
	await session.commit()
	await callback.answer()


@router.message(Command("today"))
async def cmd_today(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return

	chat_id = message.chat.id
	group = await ensure_group(session, chat_id, message.chat.title)
	today = local_today(group.tz)

	# Получаем смены на сегодня
	q_today = (
		select(Shift.type, Member.display_name, Member.user_id)
		.join(Member, (Member.chat_id == Shift.chat_id) & (Member.user_id == Shift.user_id))
		.where(Shift.chat_id == chat_id, Shift.date == today)
		.order_by(Shift.type, Member.display_name)
	)
	rows_today = (await session.execute(q_today)).all()
	
	# Получаем ночные смены на завтра (чтобы найти комбо смены)
	from datetime import timedelta
	tomorrow = today + timedelta(days=1)
	q_tomorrow = (
		select(Shift.type, Member.display_name, Member.user_id)
		.join(Member, (Member.chat_id == Shift.chat_id) & (Member.user_id == Shift.user_id))
		.where(Shift.chat_id == chat_id, Shift.date == tomorrow, Shift.type == "night")
		.order_by(Member.display_name)
	)
	rows_tomorrow = (await session.execute(q_tomorrow)).all()
	
	if not rows_today and not rows_tomorrow:
		reply = await message.reply("Сегодня смен нет.")
		asyncio.create_task(_autodelete(message, reply))
		return
	
	def mention(uid: int, name: str) -> str:
		return f"<a href=\"tg://user?id={uid}\">{name}</a>"
	
	# Группируем по пользователям для определения комбо смен
	user_shifts = {}
	
	# Обрабатываем сегодняшние смены
	for shift_type, name, uid in rows_today:
		if uid not in user_shifts:
			user_shifts[uid] = {"name": name, "types": []}
		user_shifts[uid]["types"].append(shift_type)
	
	# Обрабатываем завтрашние ночные смены (для комбо)
	for shift_type, name, uid in rows_tomorrow:
		if uid not in user_shifts:
			user_shifts[uid] = {"name": name, "types": []}
		user_shifts[uid]["types"].append("night_tomorrow")
	
	# Формируем вывод
	day_names = []
	night_names = []
	combo_names = []
	
	for uid, data in user_shifts.items():
		types = data["types"]
		name = data["name"]
		mention_text = mention(uid, name)
		
		if "day" in types and "night_tomorrow" in types:
			# Комбо смена: день сегодня + ночь завтра
			combo_names.append(mention_text)
		elif "day" in types:
			# Только дневная
			day_names.append(mention_text)
		elif "night" in types:
			# Только ночная сегодня
			night_names.append(mention_text)
		elif "night_tomorrow" in types:
			# Только ночная завтра (начинается сегодня в 21:00)
			night_names.append(mention_text)
	
	text = ""
	if day_names:
		text += "🌅 День: " + ", ".join(day_names) + "\n"
	if night_names:
		text += "🌙 Ночь: " + ", ".join(night_names) + "\n"
	if combo_names:
		text += "🌅 День/🌙 Ночь: " + ", ".join(combo_names)
		
	reply = await message.reply(text.strip(), parse_mode="HTML")
	asyncio.create_task(auto_delete_message(message, 3))


@router.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=MEMBER))
async def on_bot_added(event: ChatMemberUpdated, session: AsyncSession):
	if event.chat.type not in {"group", "supergroup"}:
		return
	if not event.new_chat_member or not event.new_chat_member.user.is_bot:
		return
	# Guard: send welcome only once
	group = await ensure_group(session, event.chat.id, event.chat.title)
	if group.welcomed_at:
		return
	await event.bot.send_message(event.chat.id, "Привет! Я бот для клинеров. Нажмите, чтобы начать регистрацию.", reply_markup=start_kb(event.from_user.username if event.from_user else None))
	group.welcomed_at = datetime.utcnow()
	session.add(group)
	await session.commit()


@router.message(Command("start"))
async def cmd_start(message: Message, session: AsyncSession, state: FSMContext):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type in {"group", "supergroup"}:
		reply = await message.reply(
			"Я бот для клинеров. Для начала — зарегистрируйтесь:", reply_markup=start_kb(message.from_user.username if message.from_user else None))
		asyncio.create_task(_autodelete(message, reply))
	else:
		await message.answer("Добавьте меня в рабочую группу и используйте команды там: /register, /shift, /today.")


@router.callback_query(F.data == "start:register", StateFilter(None))
async def cb_start_register(callback: CallbackQuery, state: FSMContext):
	st = await state.get_state()
	if st in (RegStates.waiting_name.state, RegStates.waiting_gender.state):
		await callback.answer()
		return
	await callback.message.answer(f"Отправьте имя/ник (1..{MAX_NAME_LEN} символов) или нажмите кнопку", reply_markup=register_name_kb(callback.from_user.username if callback.from_user else None))
	await state.set_state(RegStates.waiting_name)
	await callback.answer()


@router.message(Command("help"))
async def cmd_help(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	text = (
		"Доступные команды:\n"
		"/register [имя] — регистрация в группе\n"
		"/shift [YYYY-MM-DD] [day|night] — смена\n"
		"/today — кто сегодня на смене\n"
		"/cleaners — список клинеров\n"
		"/tabel — мой табель за 30 дней\n"
		"/duplicates — список дубликатов фото\n"
		"/analyze_duplicates — анализ дубликатов по участникам\n"
		"Админ: /set_schedule, /report, /who, /purge_old"
	)
	if message.chat.type in {"group", "supergroup"}:
		reply = await message.reply(text)
		asyncio.create_task(_autodelete(message, reply))
		# Удаляем команду пользователя
		asyncio.create_task(auto_delete_message(message, 3))
	else:
		await message.answer(text)


@router.message(Command("addchat"))
async def cmd_addchat(message: Message, session: AsyncSession):
	"""
	🔒 Команда владельца: добавить новую группу в список разрешенных.
	"""
	# Проверяем права владельца
	if not await check_owner_permission(message):
		await message.reply("❌ У вас нет прав для этой команды.")
		return
	
	# Проверяем что команда вызвана в группе
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("❌ Команда доступна только в группе.")
		return
	
	chat_id = message.chat.id
	chat_title = message.chat.title
	
	# Проверяем не добавлена ли уже группа
	existing = await session.execute(
		select(AllowedChat).where(AllowedChat.chat_id == chat_id)
	)
	
	if existing.scalar_one_or_none():
		await message.reply(f"✅ Группа {chat_title} уже в списке разрешенных.")
		return
	
	# Добавляем группу
	new_allowed = AllowedChat(
		chat_id=chat_id,
		chat_title=chat_title,
		added_by=OWNER_ID,
		added_at=datetime.utcnow(),
		is_active=True
	)
	session.add(new_allowed)
	await session.commit()
	
	await message.reply(f"✅ Группа {chat_title} (ID: {chat_id}) добавлена в список разрешенных!")


@router.message(Command("removechat"))
async def cmd_removechat(message: Message, session: AsyncSession):
	"""
	🔒 Команда владельца: убрать группу из списка разрешенных.
	"""
	# Проверяем права владельца
	if not await check_owner_permission(message):
		await message.reply("❌ У вас нет прав для этой команды.")
		return
	
	# Проверяем что команда вызвана в группе
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("❌ Команда доступна только в группе.")
		return
	
	chat_id = message.chat.id
	chat_title = message.chat.title
	
	# Убираем группу
	result = await session.execute(
		update(AllowedChat)
		.where(AllowedChat.chat_id == chat_id)
		.values(is_active=False)
	)
	await session.commit()
	
	if result.rowcount > 0:
		await message.reply(f"✅ Группа {chat_title} убрана из списка разрешенных. Бот покинет группу.")
		# Бот уходит из группы
		try:
			await message.chat.leave()
		except Exception:
			pass
	else:
		await message.reply(f"❌ Группа {chat_title} не найдена в списке разрешенных.")


@router.message(Command("listchats"))
async def cmd_listchats(message: Message, session: AsyncSession):
	"""
	🔒 Команда владельца: показать список разрешенных групп.
	"""
	# Проверяем права владельца
	if not await check_owner_permission(message):
		await message.reply("❌ У вас нет прав для этой команды.")
		return
	
	# Получаем список разрешенных групп
	allowed_chats = await session.execute(
		select(AllowedChat).where(AllowedChat.is_active == True).order_by(AllowedChat.added_at.desc())
	)
	
	chats = allowed_chats.scalars().all()
	
	if not chats:
		await message.reply("📋 Список разрешенных групп пуст.")
		return
	
	text = "📋 Разрешенные группы:\n\n"
	for chat in chats:
		text += f"• {chat.chat_title or 'Без названия'}\n"
		text += f"  ID: {chat.chat_id}\n"
		text += f"  Добавлена: {chat.added_at.strftime('%d.%m.%Y %H:%M')}\n\n"
	
	await message.reply(text)


@router.message(Command("myshifts"))
async def cmd_myshifts(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return
	chat_id = message.chat.id
	q = (
		select(Shift.date, Shift.type)
		.where(Shift.chat_id == chat_id, Shift.user_id == message.from_user.id)
		.order_by(Shift.date.desc())
		.limit(30)
	)
	rows = (await session.execute(q)).all()
	if not rows:
		reply = await message.reply("Смен не найдено.")
		asyncio.create_task(_autodelete(message, reply))
		return
	
	# Формируем текст с человеческими названиями смен
	shift_names = {"day": "🌅 дневная", "night": "🌙 ночная"}
	text = "Ваши смены (посл. 30):\n" + "\n".join(
		f"{d.strftime('%d.%m.%Y')} — {shift_names.get(t, t)}" for d, t in rows
	)
	reply = await message.reply(text)
	asyncio.create_task(_autodelete(message, reply))
	# Удаляем команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.message(Command("cleaners"))
async def cmd_cleaners(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return
	chat_id = message.chat.id
	# Ensure group record exists (in case /cleaners вызывают первым)
	await ensure_group(session, chat_id, message.chat.title)
	rows = (await session.execute(
		select(Member.display_name, Member.gender, Member.user_id)
		.where(Member.chat_id == chat_id)
		.order_by(Member.display_name)
	)).all()
	if not rows:
		reply = await message.reply("Нет зарегистрированных клинеров. Используйте /register, чтобы добавиться.")
		asyncio.create_task(auto_delete_message(message, 3))
		return
	def gender_mark(g: str | None) -> str:
		return "М" if g == "m" else ("Ж" if g == "f" else "?")
	def mention(uid: int, name: str) -> str:
		return f"<a href=\"tg://user?id={uid}\">{name}</a>"
	text = "Клинеры:\n" + "\n".join(f"{gender_mark(g)} — {mention(uid, name)}" for name, g, uid in rows)
	reply = await message.reply(text, parse_mode="HTML")
	asyncio.create_task(_autodelete(message, reply))
	# Удаляем команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.message(Command("duplicates"))
async def cmd_duplicates(message: Message, session: AsyncSession):
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return

	chat_id = message.chat.id
	group = await ensure_group(session, chat_id, message.chat.title)
	today = local_today(group.tz)

	# Get duplicates from last 30 days
	from datetime import timedelta
	thirty_days_ago = today - timedelta(days=30)
	
	# Получаем дубликаты с информацией об оригинале и дубликате
	rows = await session.execute(
		select(PhotoDuplicate, Photo)
		.join(Photo, PhotoDuplicate.duplicate_photo_id == Photo.id)
		.where(PhotoDuplicate.chat_id == chat_id, PhotoDuplicate.duplicate_date >= thirty_days_ago)
		.order_by(PhotoDuplicate.created_at.desc())
		.limit(50)  # Limit to prevent spam
	)
	rows = rows.all()

	if not rows:
		reply = await message.reply("Дубликатов не найдено.")
		asyncio.create_task(auto_delete_message(message, 3))
		return
	
	# Формируем читаемый список дубликатов
	lines = []
	lines.append("Дубликаты за 30 дней\n")
	
	for i, (dup, dup_photo) in enumerate(rows, 1):
		# Получаем информацию о пользователях
		dup_user = await session.get(Member, {"chat_id": chat_id, "user_id": dup_photo.user_id})
		
		# Получаем оригинальное фото отдельно
		orig_photo_result = await session.execute(
			select(Photo).where(Photo.id == dup.original_photo_id)
		)
		orig_photo = orig_photo_result.scalar_one_or_none()
		
		if orig_photo:
			orig_user = await session.get(Member, {"chat_id": chat_id, "user_id": orig_photo.user_id})
			orig_name = orig_user.display_name if orig_user else f"ID:{orig_photo.user_id}"
		else:
			orig_name = "Неизвестно"
		
		dup_name = dup_user.display_name if dup_user else f"ID:{dup_photo.user_id}"
		
		# Создаем ссылки на пользователей
		orig_link = f"[{orig_name}](tg://user?id={orig_photo.user_id})" if orig_photo else orig_name
		dup_link = f"[{dup_name}](tg://user?id={dup_photo.user_id})"
		
		# Сначала оригинал, потом дубликат
		lines.append(f"{i}. Оригинал: {orig_link}")
		lines.append(f"   {dup.original_date.strftime('%d.%m')} {str(dup.original_time)[:8]}")
		lines.append(f"   Дубликат: {dup_link}")
		lines.append(f"   {dup.duplicate_date.strftime('%d.%m')} {str(dup.duplicate_time)[:8]}")
		lines.append("")
	
	# Отправляем сообщение с форматированием
	response_text = "\n".join(lines)
	if len(response_text) > 4096:
		# Разбиваем на части если слишком длинное
		parts = [response_text[i:i+4096] for i in range(0, len(response_text), 4096)]
		for i, part in enumerate(parts):
			await message.reply(f"Часть {i+1}/{len(parts)}:\n{part}", parse_mode="Markdown")
	else:
		await message.reply(response_text, parse_mode="Markdown")
	
	# Удаляем команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.message(Command("remove"))
async def cmd_remove(message: Message, session: AsyncSession):
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return
	chat_id = message.chat.id
	await ensure_group(session, chat_id, message.chat.title)
	admin = await is_admin(chat_id, message.from_user.id, message.bot)
	reply_msg = await message.reply("Выберите действие:", reply_markup=remove_menu_kb(admin))
	# Удаляем команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.message(Command("reset"))
async def cmd_reset(message: Message, state: FSMContext):
	"""Сброс FSM состояния - если бот 'завис'"""
	current_state = await state.get_state()
	if current_state:
		await state.clear()
		reply = await message.reply("✅ Состояние сброшено. Можете начать заново с /register")
	else:
		reply = await message.reply("ℹ️ Нет активного состояния для сброса")
	# Удаляем команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.callback_query(F.data == "rm:self")
async def cb_rm_self(callback: CallbackQuery, session: AsyncSession):
	chat_id = callback.message.chat.id
	user_id = callback.from_user.id
	member = await session.get(Member, {"chat_id": chat_id, "user_id": user_id})
	if not member:
		reply_msg = await callback.message.answer("Вы не зарегистрированы в этой группе.")
		await callback.answer()
		return
	# Также удаляем все смены участника, чтобы он не отображался в /today после повторной регистрации
	await session.execute(delete(Shift).where(Shift.chat_id == chat_id, Shift.user_id == user_id))
	await session.delete(member)
	await session.commit()
	reply_msg = await callback.message.answer("Ваш профиль удалён из этой группы.")
	await callback.answer()
	
	# Удаляем сообщение через 5 секунд
	asyncio.create_task(auto_delete_message(reply_msg, 5))


@router.callback_query(F.data == "rm:other")
async def cb_rm_other(callback: CallbackQuery, session: AsyncSession):
	chat_id = callback.message.chat.id
	if not await is_admin(chat_id, callback.from_user.id, callback.bot):
		await callback.answer("Только администратор может удалять других.", show_alert=True)
		return
	rows = (await session.execute(select(Member.display_name, Member.user_id).where(Member.chat_id == chat_id).order_by(Member.display_name))).all()
	options = [(name, uid) for name, uid in rows if uid != callback.from_user.id]
	if not options:
		reply_msg = await callback.message.answer("В этой группе пока нет других клинеров для удаления.")
		await callback.answer()
		return
	reply_msg = await callback.message.answer("Кого удалить?", reply_markup=members_choice_kb(options))
	await callback.answer()
	
	# Удаляем сообщение через 1 минуту
	asyncio.create_task(auto_delete_message(reply_msg, 60))


@router.callback_query(F.data.startswith("rmuser:"))
async def cb_rm_user(callback: CallbackQuery, session: AsyncSession):
	chat_id = callback.message.chat.id
	if not await is_admin(chat_id, callback.from_user.id, callback.bot):
		await callback.answer("Только администратор может удалять других.", show_alert=True)
		return
	target_user_id = int(callback.data.split(":", 1)[1])
	member = await session.get(Member, {"chat_id": chat_id, "user_id": target_user_id})
	if not member:
		reply_msg = await callback.message.answer("Участник уже не найден в базе.")
		await callback.answer()
		return
	# Также удаляем все смены участника, чтобы он не отображался в /today после повторной регистрации
	await session.execute(delete(Shift).where(Shift.chat_id == chat_id, Shift.user_id == target_user_id))
	await session.delete(member)
	await session.commit()
	reply_msg = await callback.message.answer(f"Удалён клинер: {member.display_name}.")
	await callback.answer()
	
	# Удаляем сообщение через 5 секунд
	asyncio.create_task(auto_delete_message(reply_msg, 5))


@router.message(Command("tabel"))
async def cmd_tabel(message: Message, session: AsyncSession):
	"""
	Показать табель за 30 дней для текущего пользователя.
	Доступно только зарегистрированным клинерам.
	"""
	# 🔒 Проверяем разрешен ли чат
	if not await check_chat_allowed(message, session):
		return
	
	if message.chat.type not in {"group", "supergroup"}:
		await message.reply("Команда доступна только в группе.")
		return

	chat_id = message.chat.id
	user_id = message.from_user.id if message.from_user else 0
	
	# Проверяем регистрацию клинера
	member = await session.get(Member, {"chat_id": chat_id, "user_id": user_id})
	if not member:
		reply = await message.reply("⚠️ Сначала зарегистрируйтесь: /register")
		asyncio.create_task(auto_delete_message(message, 3))
		return

	group = await session.get(Group, chat_id)
	if not group:
		reply = await message.reply("⚠️ Группа не найдена.")
		asyncio.create_task(auto_delete_message(message, 3))
		return

	now = local_now(group.tz)
	today = now.date()
	start_date = today - timedelta(days=29)  # 30 дней включая сегодня
	
	# Получаем табель за 30 дней
	timesheet_result = await session.execute(
		select(Timesheet).where(
			Timesheet.chat_id == chat_id,
			Timesheet.user_id == user_id,
			Timesheet.date >= start_date,
			Timesheet.date <= today
		).order_by(Timesheet.date.asc())
	)
	timesheet_entries = timesheet_result.scalars().all()
	
	if not timesheet_entries:
		reply = await message.reply(f"📋 **Табель {member.display_name}**\n\nЗа последние 30 дней рабочих дней не найдено.\n_Для записи в табель нужно: выбрать смену + отправить 10+ фото._")
		asyncio.create_task(auto_delete_message(message, 3))
		return
	
	# Формируем отчет табеля
	response_lines = [f"📋 **Табель {member.display_name}** (последние 30 дней)"]
	response_lines.append("")
	
	# Группируем по дате для правильного отображения комбинированных смен
	entries_by_date = {}
	for entry in timesheet_entries:
		date_key = entry.date
		if date_key not in entries_by_date:
			entries_by_date[date_key] = {}
		entries_by_date[date_key][entry.shift_type] = entry
	
	total_days = len(entries_by_date)
	day_only = sum(1 for entries in entries_by_date.values() if "day" in entries and "night" not in entries)
	night_only = sum(1 for entries in entries_by_date.values() if "night" in entries and "day" not in entries)
	combined_days = sum(1 for entries in entries_by_date.values() if "day" in entries and "night" in entries)
	
	response_lines.append(f"**Итого рабочих дней:** {total_days}")
	response_lines.append(f"🌅 Только дневных: {day_only}")
	response_lines.append(f"🌙 Только ночных: {night_only}")
	if combined_days > 0:
		response_lines.append(f"🌅🌙 Комбинированных (день+ночь): {combined_days}")
	response_lines.append("")
	response_lines.append("**Детали:**")
	
	# Отображаем записи по датам
	for work_date in sorted(entries_by_date.keys()):
		date_entries = entries_by_date[work_date]
		date_str = work_date.strftime('%d.%m')
		
		if "day" in date_entries and "night" in date_entries:
			# Комбинированная смена
			day_photos = date_entries["day"].photo_count
			night_photos = date_entries["night"].photo_count
			total_photos = day_photos + night_photos
			response_lines.append(f"{date_str} 🌅🌙 день+ночь ({day_photos}+{night_photos}={total_photos} фото)")
		elif "day" in date_entries:
			# Только дневная
			entry = date_entries["day"]
			response_lines.append(f"{date_str} 🌅 дневная ({entry.photo_count} фото)")
		elif "night" in date_entries:
			# Только ночная
			entry = date_entries["night"]
			response_lines.append(f"{date_str} 🌙 ночная ({entry.photo_count} фото)")
	
	response_text = "\n".join(response_lines)
	
	# Отправляем табель и НЕ удаляем автоматически (важная информация)
	reply = await message.reply(response_text, parse_mode="Markdown")
	
	# Удаляем только команду пользователя
	asyncio.create_task(auto_delete_message(message, 3))


@router.callback_query(F.data.startswith("analyze:"))
async def cb_analyze_user(callback: CallbackQuery, session: AsyncSession):
	chat_id = callback.message.chat.id
	target_user_id = int(callback.data.split(":", 1)[1])
	
	await callback.answer("⏳ Анализирую дубликаты...")
	
	try:
		# Получаем информацию о пользователе
		chat_member = await callback.bot.get_chat_member(chat_id, target_user_id)
		user_name = chat_member.user.username or f"ID:{target_user_id}"
		
		# Анализируем дубликаты пользователя
		duplicates = await analyze_user_duplicates(session, chat_id, target_user_id)
		
		if not duplicates:
			await callback.message.edit_text(f"✅ У {user_name} дубликатов не найдено.")
			return
		
		# Формируем отчет
		report = f"📊 Анализ дубликатов для {user_name}:\n\n"
		total_duplicates = 0
		
		for dup in duplicates:
			total_duplicates += 1
			report += f"🔍 Дубликат #{total_duplicates}:\n"
			report += f"   📅 Оригинал: {dup.original_date.isoformat()} в {str(dup.original_time)[:8]}\n"
			report += f"   📅 Дубликат: {dup.duplicate_date.isoformat()} в {str(dup.duplicate_time)[:8]}\n"
			report += f"   ⏱️ Разница: {dup.time_diff}\n\n"
		
		report += f"📈 Итого найдено дубликатов: {total_duplicates}"
		
		await callback.message.edit_text(report)
		
	except Exception as e:
		await callback.message.edit_text(f"❌ Ошибка при анализе: {str(e)}")


async def analyze_user_duplicates(session: AsyncSession, chat_id: int, user_id: int) -> list:
	"""
	Анализирует дубликаты конкретного пользователя.
	Возвращает список дубликатов с дополнительной информацией.
	"""
	# Получаем все дубликаты пользователя
	q = (
		select(PhotoDuplicate)
		.where(PhotoDuplicate.chat_id == chat_id)
		.where(
			# Дубликат от этого пользователя
			(PhotoDuplicate.duplicate_photo_id.in_(
				select(Photo.id).where(Photo.chat_id == chat_id, Photo.user_id == user_id)
			)) |
			# Или оригинал от этого пользователя
			(PhotoDuplicate.original_photo_id.in_(
				select(Photo.id).where(Photo.chat_id == chat_id, Photo.user_id == user_id)
			))
		)
		.order_by(PhotoDuplicate.created_at.desc())
	)
	
	duplicates = (await session.execute(q)).scalars().all()
	
	# Добавляем информацию о времени между оригиналом и дубликатом
	for dup in duplicates:
		original_dt = datetime.combine(dup.original_date, dup.original_time.replace(tzinfo=None))
		duplicate_dt = datetime.combine(dup.duplicate_date, dup.duplicate_time.replace(tzinfo=None))
		time_diff = abs(duplicate_dt - original_dt)
		
		if time_diff.days > 0:
			dup.time_diff = f"{time_diff.days} дней"
		elif time_diff.seconds > 3600:
			dup.time_diff = f"{time_diff.seconds // 3600} часов"
		elif time_diff.seconds > 60:
			dup.time_diff = f"{time_diff.seconds // 60} минут"
		else:
			dup.time_diff = f"{time_diff.seconds} секунд"
	
	return duplicates


async def _upsert_shift(session: AsyncSession, chat_id: int, user_id: int, shift_date: date, shift_type: str) -> None:
	# Ensure member exists
	member = await session.get(Member, {"chat_id": chat_id, "user_id": user_id})
	if not member:
		raise ValueError("Сначала зарегистрируйтесь: /register")

	existing = await session.execute(
		select(Shift).where(Shift.chat_id == chat_id, Shift.user_id == user_id, Shift.date == shift_date)
	)
	shift = existing.scalar_one_or_none()
	if shift:
		shift.type = shift_type
	else:
		shift = Shift(
			chat_id=chat_id,
			user_id=user_id,
			date=shift_date,
			type=shift_type,
			created_at=datetime.utcnow(),
		)
		session.add(shift)
	await session.commit()


async def _autodelete(src: Message, reply: Message, delay: int = 15) -> None:
	try:
		await asyncio.sleep(delay)
		await reply.delete()
		await src.delete()
	except Exception:
		return 