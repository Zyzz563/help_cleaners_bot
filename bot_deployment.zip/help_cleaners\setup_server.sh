#!/bin/bash

echo "🖥️  Настройка сервера для Help Cleaners Bot..."

# Обновление системы
echo "📦 Обновление системы..."
sudo apt update && sudo apt upgrade -y

# Установка Docker
echo "🐳 Установка Docker..."
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Установка Docker Compose
echo "📋 Установка Docker Compose..."
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Установка дополнительных утилит
echo "🔧 Установка утилит..."
sudo apt install -y htop nano curl wget

# Создание директорий
echo "📁 Создание директорий..."
mkdir -p ~/help_cleaners/{data,logs}
cd ~/help_cleaners

echo "✅ Настройка сервера завершена!"
echo "🔑 Перезайдите в систему или выполните: newgrp docker"
echo "📁 Перейдите в директорию: cd ~/help_cleaners"
echo "🚀 Запустите бота: ./deploy.sh" 